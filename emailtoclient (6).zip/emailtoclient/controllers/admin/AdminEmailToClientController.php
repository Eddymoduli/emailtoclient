<?php

class AdminEmailToClientController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {
        if (Tools::isSubmit('submit_send_email')) {
            $this->processSendEmail();
        }

        parent::initContent();

        // Carichiamo i dati per clienti, gruppi e categorie
        $this->context->smarty->assign([
            'customers'     => $this->getAllCustomers(),
            'groups'        => $this->getAllGroups(),
            'categories'    => $this->getAllCategories(),
            'token'         => Tools::getAdminTokenLite('AdminEmailToClient'),
            'module_dir'    => _PS_MODULE_DIR_.$this->module->name,
            'email_subject' => Tools::getValue('email_subject', ''),
            'email_message' => Tools::getValue('email_message', ''),
        ]);

        $this->setTemplate('emailtoclient/index.tpl');
    }

    // -------------------------------------------------------------
    //    RECUPERO DI CLIENTI, GRUPPI, CATEGORIE
    // -------------------------------------------------------------
    private function getAllCustomers()
    {
        $sql = new DbQuery();
        $sql->select('c.id_customer, c.email, c.firstname, c.lastname, c.id_default_group');
        $sql->from('customer', 'c');
        $sql->where('c.active = 1');
        $sql->orderBy('c.firstname ASC, c.lastname ASC');
        return Db::getInstance()->executeS($sql);
    }

    private function getAllGroups()
    {
        $id_lang = (int)$this->context->language->id;
        $sql = new DbQuery();
        $sql->select('g.id_group, g.name');
        $sql->from('group_lang', 'g');
        $sql->where('g.id_lang = '.$id_lang);
        $sql->orderBy('g.name ASC');
        return Db::getInstance()->executeS($sql);
    }

    private function getAllCategories()
    {
        $id_lang = (int)$this->context->language->id;
        $sql = new DbQuery();
        $sql->select('c.id_category, cl.name');
        $sql->from('category', 'c');
        $sql->innerJoin('category_lang', 'cl', 'cl.id_category = c.id_category AND cl.id_lang = '.$id_lang);
        $sql->where('c.active = 1 AND c.id_category > 1');
        $sql->orderBy('cl.name ASC');
        return Db::getInstance()->executeS($sql);
    }

    // -------------------------------------------------------------
    //    INVIO EMAIL
    // -------------------------------------------------------------
    private function processSendEmail()
    {
        $subject      = Tools::getValue('email_subject');
        $message      = Tools::getValue('email_message');
        $customer_ids = Tools::getValue('select_customers'); // array
        $group_ids    = Tools::getValue('select_groups');    // array
        $product_ids  = Tools::getValue('select_products');  // array (selezionati in tabella AJAX)

        if (!$subject || !$message) {
            $this->errors[] = $this->l('Oggetto e Messaggio sono obbligatori.');
            return;
        }

        $recipients = $this->getRecipientsList($customer_ids, $group_ids);
        if (empty($recipients)) {
            $this->errors[] = $this->l('Nessun destinatario selezionato.');
            return;
        }

        // Costruiamo la tabella prodotti (se ce ne sono)
        $products_html = $this->buildProductsTable($product_ids, $group_ids, $customer_ids);
        if ($products_html) {
            $message .= '<hr><p><strong>Prodotti selezionati:</strong></p>'.$products_html;
        }

        $success_count = 0;
        foreach ($recipients as $r) {
            if ($this->sendEmail($subject, $message, $r['email'], $r['firstname'].' '.$r['lastname'])) {
                $success_count++;
            }
        }

        // Salviamo log
        $this->saveEmailLog($subject, $message, $this->formatRecipientsLog($recipients));

        if ($success_count > 0) {
            $this->confirmations[] = $this->l('Email inviate con successo a ').$success_count.$this->l(' destinatari!');
        } else {
            $this->errors[] = $this->l('Nessuna email inviata. Controlla configurazione SMTP o altri errori.');
        }
    }

    /**
     * Clienti + Gruppi
     */
    private function getRecipientsList($customer_ids, $group_ids)
    {
        if (!is_array($customer_ids)) {
            $customer_ids = [];
        }
        if (!is_array($group_ids)) {
            $group_ids = [];
        }

        $customers_list = [];
        if (!empty($customer_ids)) {
            $sql = new DbQuery();
            $sql->select('id_customer, email, firstname, lastname, id_default_group');
            $sql->from('customer');
            $sql->where('active = 1 AND id_customer IN ('.implode(',', array_map('intval', $customer_ids)).')');
            $customers_list = Db::getInstance()->executeS($sql);
        }

        $customers_from_groups = [];
        if (!empty($group_ids)) {
            $sql = new DbQuery();
            $sql->select('c.id_customer, c.email, c.firstname, c.lastname, c.id_default_group');
            $sql->from('customer', 'c');
            $sql->innerJoin('customer_group', 'cg', 'cg.id_customer = c.id_customer');
            $sql->where('c.active = 1 AND cg.id_group IN ('.implode(',', array_map('intval', $group_ids)).')');
            $customers_from_groups = Db::getInstance()->executeS($sql);
        }

        $all = array_merge($customers_list, $customers_from_groups);

        // Rimuovere duplicati
        $unique = [];
        foreach ($all as $cust) {
            $key = $cust['id_customer'].'-'.$cust['email'];
            $unique[$key] = $cust;
        }

        return array_values($unique);
    }

    private function sendEmail($subject, $message, $to_email, $to_name)
    {
        $template = 'emailtoclient';
        $params = [
            '{custom_content}' => $message
        ];

        return Mail::Send(
            (int)$this->context->language->id,
            $template,
            $subject,
            $params,
            $to_email,
            $to_name,
            null,
            null,
            null,
            null,
            _PS_MODULE_DIR_.$this->module->name.'/mails/',
            false,
            (int)$this->context->shop->id
        );
    }

    private function saveEmailLog($subject, $message, $recipients)
    {
        $insert = [
            'subject'    => pSQL($subject),
            'message'    => pSQL($message, true),
            'recipients' => pSQL($recipients, true),
            'date_add'   => date('Y-m-d H:i:s'),
        ];
        Db::getInstance()->insert('emailtoclient_log', $insert);
    }

    private function formatRecipientsLog($recipients)
    {
        $arr = [];
        foreach ($recipients as $r) {
            $arr[] = $r['firstname'].' '.$r['lastname'].' <'.$r['email'].'>';
        }
        return implode(', ', $arr);
    }

    // -------------------------------------------------------------
    //  CALCOLO PREZZO, NUOVA LOGICA
    // -------------------------------------------------------------
    /**
     * Crea la tabella prodotti (immagini, nome, prezzo) in base a:
     * - Se c'è esattamente 1 gruppo => prezzo di quel gruppo
     * - altrimenti, se c'è esattamente 1 cliente => prezzo del suo default_group
     * - altrimenti => prezzo base
     */
    private function buildProductsTable($product_ids, $group_ids, $customer_ids)
    {
        if (!is_array($product_ids) || !count($product_ids)) {
            return '';
        }

        // 1) Se c'è esattamente 1 gruppo spuntato
        if (is_array($group_ids) && count($group_ids) === 1) {
            $id_group_for_price = (int)$group_ids[0];
        } 
        // 2) Altrimenti, se c'è esattamente 1 cliente
        else if (is_array($customer_ids) && count($customer_ids) === 1) {
            // Recuperiamo quel cliente e prendiamo il suo id_default_group
            $id_customer = (int)$customer_ids[0];
            $id_group_for_price = $this->getDefaultGroupOfCustomer($id_customer);
        }
        // 3) Nessun gruppo, nessun “cliente unico”
        else {
            $id_group_for_price = 0; // Prezzo base
        }

        $products = $this->getProductsInfo($product_ids, $id_group_for_price);
        if (!$products) {
            return '';
        }

        // Tabella HTML
        $html = '<table border="1" cellpadding="5" cellspacing="0" style="border-collapse:collapse;">';
        $html .= '<thead><tr><th>Immagine</th><th>Prodotto</th><th>Prezzo</th></tr></thead>';
        $html .= '<tbody>';

        foreach ($products as $p) {
            $img_url = $this->getProductImageUrl($p['id_product'], $p['id_image']);
            $link    = $this->context->link->getProductLink($p['id_product']);
            $html .= '<tr>';
            $html .= '<td><img src="'.$img_url.'" alt="" width="50" /></td>';
            $html .= '<td><a href="'.$link.'" target="_blank">'.Tools::safeOutput($p['name']).'</a></td>';
            $html .= '<td>'.Tools::displayPrice($p['price']).'</td>';
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';

        return $html;
    }

    private function getDefaultGroupOfCustomer($id_customer)
    {
        $row = Db::getInstance()->getRow('
            SELECT id_default_group 
            FROM '._DB_PREFIX_.'customer
            WHERE id_customer='.(int)$id_customer
        );
        if ($row && $row['id_default_group']) {
            return (int)$row['id_default_group'];
        }
        return 0;
    }

    /**
     * Ottenimento info prodotti + prezzo in base a $id_group_for_price
     */
    private function getProductsInfo($product_ids, $id_group_for_price)
    {
        $id_lang = (int)$this->context->language->id;

        $sql = new DbQuery();
        $sql->select('p.id_product, pl.name, p.price AS base_price, i.id_image');
        $sql->from('product', 'p');
        $sql->innerJoin('product_lang', 'pl', 'pl.id_product = p.id_product AND pl.id_lang = '.$id_lang);
        $sql->leftJoin('image', 'i', 'i.id_product = p.id_product AND i.cover = 1');
        $sql->where('p.id_product IN ('.implode(',', array_map('intval', $product_ids)).')');
        $sql->orderBy('pl.name ASC');

        $results = Db::getInstance()->executeS($sql);
        if (!$results) {
            return [];
        }

        foreach ($results as &$r) {
            if ($id_group_for_price > 0) {
                // Prezzo ridotto in base a un gruppo
                $r['price'] = $this->getPriceForGroup($r['id_product'], $id_group_for_price);
            } else {
                // Prezzo base
                $r['price'] = $r['base_price'];
            }
        }

        return $results;
    }

    /**
     * Funzione per calcolare il prezzo di un prodotto per un determinato gruppo
     */
    private function getPriceForGroup($id_product, $id_group)
    {
        // Salviamo il customer attuale
        $old_customer = $this->context->customer;

        // Creiamo un finto "customer" col default_group
        $fake_customer = new Customer();
        $fake_customer->id_default_group = $id_group;

        // Impostiamo nel context
        $this->context->customer = $fake_customer;

        // Otteniamo il prezzo con getPriceStatic (tassato, con riduzioni)
        $price = Product::getPriceStatic($id_product, true, null, 2);

        // Ripristina context
        $this->context->customer = $old_customer;
        return $price;
    }

    private function getProductImageUrl($id_product, $id_image)
    {
        if (!$id_image) {
            // Placeholder
            return __PS_BASE_URI__.'img/p/en-default-home_default.jpg';
        }
        return $this->context->link->getImageLink('fake-rewrite', $id_image, 'home_default');
    }


    // -------------------------------------------------------------
    //  CHIAMATA AJAX: displayAjaxGetProducts()
    // -------------------------------------------------------------
    public function displayAjaxGetProducts()
    {
        // param: categories, search_query, selected_groups, e adesso anche selected_customers
        $categories_json = Tools::getValue('categories');
        $search_query    = Tools::getValue('search_query');
        $groups_json     = Tools::getValue('selected_groups');
        $customers_json  = Tools::getValue('selected_customers'); // AGGIUNTO

        $categories = $categories_json ? json_decode($categories_json, true) : [];
        $selected_groups = $groups_json ? json_decode($groups_json, true) : [];
        $selected_customers = $customers_json ? json_decode($customers_json, true) : [];

        $found_products = $this->searchProducts($categories, $search_query, $selected_groups, $selected_customers);

        // Costruiamo la tabella con i checkbox + pulsanti "Seleziona tutti"
        $html_table = $this->renderProductTableHtml($found_products);

        die(Tools::jsonEncode([
            'html' => $html_table
        ]));
    }

    /**
     * Filtro prodotti + calcolo prezzo se 1 solo gruppo o 1 solo cliente
     */
    private function searchProducts($category_ids, $search, $group_ids, $customer_ids)
    {
        $id_lang = (int)$this->context->language->id;

        // Prepariamo la query
        $sql = new DbQuery();
        $sql->select('p.id_product, pl.name, p.price as base_price, i.id_image');
        $sql->from('product', 'p');
        $sql->innerJoin('product_lang', 'pl', 'pl.id_product = p.id_product AND pl.id_lang = '.$id_lang);
        $sql->leftJoin('image', 'i', 'i.id_product = p.id_product AND i.cover = 1');
        $sql->where('p.active = 1');

        // Filtro categorie
        // Se non ci sono categorie selezionate e nemmeno ricerca, non mostrare nulla
        if ((!is_array($category_ids) || count($category_ids) === 0) && (!$search || mb_strlen($search) < 3)) {
            return [];
        }
        if (is_array($category_ids) && count($category_ids)) {
            $sql->innerJoin('category_product', 'cp', 'cp.id_product = p.id_product');
            $sql->where('cp.id_category IN ('.implode(',', array_map('intval', $category_ids)).')');
        }

        // Filtro testo (>=3 char)
        if ($search && mb_strlen($search) >= 3) {
            $search_esc = pSQL($search);
            $sql->where('pl.name LIKE \'%'.$search_esc.'%\'');
        }

        $sql->orderBy('pl.name ASC');
        $results = Db::getInstance()->executeS($sql);
        if (!$results) {
            return [];
        }

        // Determiniamo quale group ID usare
        if (is_array($group_ids) && count($group_ids) === 1) {
            // 1 solo gruppo
            $id_group_for_price = (int)$group_ids[0];
        } else if (is_array($customer_ids) && count($customer_ids) === 1) {
            // 1 solo cliente => recuperiamo default group
            $id_group_for_price = $this->getDefaultGroupOfCustomer((int)$customer_ids[0]);
        } else {
            // Prezzo base
            $id_group_for_price = 0;
        }

        foreach ($results as &$r) {
            if ($id_group_for_price > 0) {
                $r['price'] = $this->getPriceForGroup($r['id_product'], $id_group_for_price);
            } else {
                $r['price'] = $r['base_price'];
            }
        }

        return $results;
    }

    /**
     * Genera l'HTML della tabella con check + pulsanti "Seleziona tutti"
     */
    private function renderProductTableHtml($products)
    {
        if (!$products) {
            return '<p>Nessun prodotto trovato.</p>';
        }

        // Pulsanti in alto
        $html = '
        <div class="btn-group" style="margin-bottom:10px;">
          <button type="button" class="btn btn-default" id="select_all_products_btn">Seleziona tutti i prodotti</button>
          <button type="button" class="btn btn-default" id="deselect_all_products_btn">Deseleziona tutti i prodotti</button>
        </div>
        ';

        // Tabella con check
        $html .= '<table class="table table-bordered">';
        $html .= '<thead><tr>
          <th>Seleziona</th>
          <th>Immagine</th>
          <th>Prodotto</th>
          <th>Prezzo</th>
        </tr></thead><tbody>';

        foreach ($products as $p) {
            $img_url  = $this->getProductImageUrl($p['id_product'], $p['id_image']);
            $name     = Tools::safeOutput($p['name']);
            $price    = Tools::displayPrice($p['price']);

            $html .= '<tr>';
            $html .= '<td><input type="checkbox" name="select_products[]" value="'.(int)$p['id_product'].'"></td>';
            $html .= '<td><img src="'.$img_url.'" width="50" /></td>';
            $html .= '<td>'.$name.'</td>';
            $html .= '<td>'.$price.'</td>';
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';

        // Script inline per i pulsanti "Seleziona/Deseleziona"
        // Usiamo #ajax-product-list come contenitore
        // Attenzione: i querySelectorAll() vanno rifatti dopo che l'HTML è inserito
        $html .= '
        <script type="text/javascript">
        (function(){
          var sap = document.getElementById("select_all_products_btn");
          var dap = document.getElementById("deselect_all_products_btn");
          if (sap && dap) {
            sap.addEventListener("click", function() {
              document.querySelectorAll("#ajax-product-list input[name=\'select_products[]\']").forEach(function(chk) {
                chk.checked = true;
              });
            });
            dap.addEventListener("click", function() {
              document.querySelectorAll("#ajax-product-list input[name=\'select_products[]\']").forEach(function(chk) {
                chk.checked = false;
              });
            });
          }
        })();
        </script>
        ';

        return $html;
    }
}
