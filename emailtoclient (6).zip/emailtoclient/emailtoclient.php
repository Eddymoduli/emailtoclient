<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class EmailToClient extends Module
{
    public function __construct()
    {
        $this->name = 'emailtoclient';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Eduardo';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Invio Email al Cliente');
        $this->description = $this->l('Modulo per inviare email personalizzate a clienti o gruppi di clienti.');
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => '1.7.8.99'];
    }

    public function install()
    {
        return parent::install() && $this->createDbTable();
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->dropDbTable();
    }

    private function createDbTable()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'emailtoclient_log` (
            `id_emailtoclient_log` INT(11) NOT NULL AUTO_INCREMENT,
            `subject` VARCHAR(255) NOT NULL,
            `message` TEXT NOT NULL,
            `recipients` TEXT NOT NULL,
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_emailtoclient_log`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';
        return Db::getInstance()->execute($sql);
    }

    private function dropDbTable()
    {
        $sql = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'emailtoclient_log`;';
        return Db::getInstance()->execute($sql);
    }

    public function getContent()
    {
        $controller_url = $this->context->link->getAdminLink('AdminEmailToClient');
        Tools::redirectAdmin($controller_url);
    }
}
